#import "TException.h"

@interface TProtocolException : TException {
}

@end
