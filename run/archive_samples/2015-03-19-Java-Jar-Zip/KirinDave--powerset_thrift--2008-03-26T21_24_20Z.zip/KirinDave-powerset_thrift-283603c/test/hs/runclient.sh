#!/bin/bash
ghci -fglasgow-exts -i/home/iproctor/code/projects/thrift/trunk/lib/hs/src -igen-hs Client.hs
