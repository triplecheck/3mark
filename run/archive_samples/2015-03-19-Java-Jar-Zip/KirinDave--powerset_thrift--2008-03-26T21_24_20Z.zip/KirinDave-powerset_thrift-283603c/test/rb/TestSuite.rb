#!/usr/bin/env ruby

require 'test/unit'
require 'TestThrift'
require 'TestSmallService'
