This folder contains the generated reports
