
/*


This file does not contain any licenses. I'll copy some text here:

"1) Find a license from the license database
2) Find a <Java> file and paste the license text based on the source file format
3) Use the <Java> file as input for commandline option and see if the input results with correct matching output"

"1) Copy from somewhere some text
2) Paste it into a source file with its comment format
3) The system should provide a ""no matching"" result"

"1) Find a license from the license database
2) Do some changes to the license
3) Find a <Java> file and paste the changed license text based on the source file format
4) use the <Java> file as input for commandline option and see if the input results with correct matching output"





*/


foo.

