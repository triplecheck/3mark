#!/bin/bash

rm *.meta *.txt
source ./create_template.sh
source ./create_meta.sh
