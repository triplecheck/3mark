/*
*
*       License: creative commons - attribution, share-alike 
*       Copyright Ian Lesnet and friends 2011
*       http://dangerousprototypes.com
*
*/

#ifndef CONFIG_H
#define CONFIG_H
_CONFIG1( JTAGEN_OFF & GCP_OFF & GWRP_OFF & FWDTEN_OFF & ICS_PGx2) 
_CONFIG2(0xABFE)
#endif
