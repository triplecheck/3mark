/*
Author: Daniele Fognini, Andreas Wuerl
Copyright (C) 2013-2014, Siemens AG

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License version 2 as published by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
*/

#define _GNU_SOURCE
#include <stdio.h>

#include "database.h"
#include "libfossdb.h"
#include "libfossdbmanager.h"

char* getUploadTreeTableName (fo_dbManager* dbManager, int uploadId) {
char* result;
PGresult* resTableName= fo_dbManager_ExecPrepared(
                            fo_dbManager_PrepareStamement(
                              dbManager,
                              "getUploadTreeTableName",
                              "SELECT uploadtree_tablename from upload where upload_pk=$1 limit 1",
                              int),
                            uploadId
                          );
  if (!resTableName) {
    result = g_strdup("uploadtree");
    return result;
    }

  if (PQntuples(resTableName) == 0) {
    PQclear(resTableName);
     result = g_strdup("uploadtree");
     return result;
  }


  result = strdup(PQgetvalue(resTableName, 0, 0));
  PQclear(resTableName);
  return result;

}


PGresult* queryFileIdsForUpload(fo_dbManager* dbManager, int uploadId) {

  PGresult* result;

  char* uploadtreeTableName = getUploadTreeTableName(dbManager, uploadId);

  if(strcmp (uploadtreeTableName, "uploadtree_a") == 0){
    char* queryName = g_strdup_printf ("queryFileIdsForUpload.%s",uploadtreeTableName);
    char* sql ;
    sql = g_strdup_printf ("select distinct(pfile_fk) from %s where upload_fk=$1 and (ufile_mode&x'3C000000'::int)=0",
                uploadtreeTableName);

    result = fo_dbManager_ExecPrepared(
              fo_dbManager_PrepareStamement(
                dbManager,
                queryName,
                sql,
                int),
              uploadId
            );

    g_free(sql);
    g_free(queryName);
  }
  else {

    result = fo_dbManager_Exec_printf(dbManager,
                "select distinct(pfile_fk) from %s where (ufile_mode&x'3C000000'::int)=0",
                              uploadtreeTableName
                );
  }

  g_free(uploadtreeTableName);

  return result;
}

char* queryPFileForFileId(fo_dbManager* dbManager, long fileId) {
  PGresult* fileNameResult = fo_dbManager_ExecPrepared(
    fo_dbManager_PrepareStamement(
      dbManager,
      "queryPFileForFileId",
      "select pfile_sha1 || '.' || pfile_md5 ||'.'|| pfile_size AS pfilename from pfile where pfile_pk=$1",
      long),
    fileId
  );

  if (PQntuples(fileNameResult) == 0) {
    PQclear(fileNameResult);
    return NULL;
  }

  char* pFile = strdup(PQgetvalue(fileNameResult, 0, 0));
  PQclear(fileNameResult);
  return pFile;
}

//TODO use correct parameters to filter only "good" licenses
PGresult* queryAllLicenses(fo_dbManager* dbManager) {
  return fo_dbManager_ExecPrepared(
    fo_dbManager_PrepareStamement(
      dbManager,
      "queryAllLicenses",
      "select rf_pk, rf_shortname from license_ref where rf_detector_type != 2"
    )
  );
}

char* getLicenseTextForLicenseRefId(fo_dbManager* dbManager, long refId) {
  PGresult* licenseTextResult = fo_dbManager_ExecPrepared(
    fo_dbManager_PrepareStamement(
      dbManager,
      "getLicenseTextForLicenseRefId",
      "select rf_text from license_ref where rf_pk = $1",
      long),
    refId
  );

  if (PQntuples(licenseTextResult) != 1) {
    printf("cannot find license text!\n");
    PQclear(licenseTextResult);
    return "";
  }

  char* result = strdup(PQgetvalue(licenseTextResult, 0, 0));
  PQclear(licenseTextResult);
  return result;
}

char* getFileNameForFileId(fo_dbManager* dbManager, long pFileId) {
  //TODO discuss TODO with Daniele
//! TODO eliminate the use of uploadtree => getUploadTreeTableName, also this might be buggy if there is more than one filename per pfile_fk(if you only read the file to scan it, it is OK)
  char* result;
  PGresult* resultUploadFilename = fo_dbManager_ExecPrepared(
    fo_dbManager_PrepareStamement(
      dbManager,
      "getFileNameForFileId",
      "select ufile_name from uploadtree where pfile_fk = $1",
      long),
    pFileId
  );

  if (!resultUploadFilename)
    return NULL;

  if (PQntuples(resultUploadFilename) == 0) {
    PQclear(resultUploadFilename);
    return NULL;
  }

  result = strdup(PQgetvalue(resultUploadFilename, 0, 0));
  PQclear(resultUploadFilename);
  return result;
}

int hasAlreadyResultsFor(fo_dbManager* dbManager, int agentId, long pFileId) {
  PGresult * insertResult = fo_dbManager_ExecPrepared(
    fo_dbManager_PrepareStamement(
      dbManager,
      "hasAlreadyResultsFor",
      "SELECT 1 WHERE EXISTS (SELECT 1"
      " FROM license_file WHERE agent_fk = $1 AND pfile_fk = $2"
      ")",
      int, long),
    agentId, pFileId
  );

  int exists = 0;
  if (insertResult) {
    exists = (PQntuples(insertResult)==1);
    PQclear(insertResult);
  }

  return exists;
}

long saveToDb(fo_dbManager* dbManager, int agentId, long refId, long pFileId, unsigned percent) {
  PGresult * insertResult = fo_dbManager_ExecPrepared(
    fo_dbManager_PrepareStamement(
      dbManager,
      "saveToDb",
      "insert into license_file(rf_fk, agent_fk, pfile_fk, rf_match_pct) values($1,$2,$3,$4) RETURNING fl_pk",
      long, int, long, unsigned),
    refId, agentId, pFileId, percent
  );

  long licenseFilePk = -1;
  if (insertResult) {
    if (PQntuples(insertResult)==1) {
      licenseFilePk = atol(PQgetvalue(insertResult, 0, 0));
    }
    PQclear(insertResult);
  }

  return licenseFilePk;
}

int saveHighlightToDb(fo_dbManager* dbManager, char* type, DiffPoint* highlight, long licenseFileId){
  PGresult* insertResult = fo_dbManager_ExecPrepared(
    fo_dbManager_PrepareStamement(
      dbManager,
      "saveHighlightToDb",
      "insert into highlight(fl_fk, type, start, len) values($1,$2,$3,$4)",
      long, char*, size_t, size_t),
    licenseFileId, type, highlight->start, highlight->length
  );

  if (!insertResult)
    return 0;

  PQclear(insertResult);

  return 1;
}

inline int saveDiffHighlightToDb(fo_dbManager* dbManager, DiffMatchInfo* diffInfo, long licenseFileId) {
  PGresult* insertResult = fo_dbManager_ExecPrepared(
    fo_dbManager_PrepareStamement(
      dbManager,
      "saveDiffHighlightToDb",
      "insert into highlight(fl_fk, type, start, len, rf_start, rf_len) values($1,$2,$3,$4,$5,$6)",
      long, char*, size_t, size_t, size_t, size_t),
    licenseFileId,
    diffInfo->diffType,
    diffInfo->text.start, diffInfo->text.length,
    diffInfo->search.start, diffInfo->search.length
  );

  if (!insertResult)
    return 0;

  PQclear(insertResult);

  return 1;
}

int saveDiffHighlightsToDb(fo_dbManager* dbManager, GArray* matchedInfo, long licenseFileId) {
  size_t matchedInfoLen = matchedInfo->len ;
  for (size_t i = 0; i < matchedInfoLen; i++){
    DiffMatchInfo* diffMatchInfo = &g_array_index(matchedInfo, DiffMatchInfo, i);
    if (!saveDiffHighlightToDb(dbManager, diffMatchInfo, licenseFileId))
      return 0;
  }

  return 1;
};
