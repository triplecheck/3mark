To test adj2nest by simulating the scheduler:

  adj2nest --userID={user_pk} --scheduler_start {upload_pk}
eg.  adj2nest --userID=3 --scheduler_start 27
