module Spec
  module Mocks
    class MockExpectationError < StandardError
    end
    
    class AmbiguousReturnError < StandardError
    end
  end
end

