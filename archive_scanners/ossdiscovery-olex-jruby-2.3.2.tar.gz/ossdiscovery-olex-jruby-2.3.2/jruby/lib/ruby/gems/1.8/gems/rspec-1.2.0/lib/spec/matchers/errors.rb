module Spec
  module Matchers
    class MatcherError < StandardError; end
  end
end