require File.dirname(__FILE__) + '/../../spec_helper.rb'

describe "Running an Example" do
  it "should not output twice" do
    true.should be_true
  end
end