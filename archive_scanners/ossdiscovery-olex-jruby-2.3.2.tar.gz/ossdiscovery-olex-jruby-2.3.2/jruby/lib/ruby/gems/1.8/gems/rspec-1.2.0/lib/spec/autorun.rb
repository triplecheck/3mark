require 'spec'

Spec::Runner.autorun