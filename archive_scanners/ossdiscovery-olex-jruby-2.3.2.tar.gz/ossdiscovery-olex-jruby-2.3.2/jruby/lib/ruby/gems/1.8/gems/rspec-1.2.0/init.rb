# Placeholder to satisfy Rails.
#
# Do NOT add any require statements to this file. Doing
# so will cause Rails to load this plugin all of the time.
#
# Running 'ruby script/generate rspec' will
# generate spec/spec_helper.rb, which includes the necessary
# require statements and configuration. This file should
# be required by all of your spec files.