module JRuby
  module OpenSSL
    GEM_ONLY = true
  end
end